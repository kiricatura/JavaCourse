package com.company;

public class Main {

    public static void main(String[] args) {

        /*
        String name = moshe();
        System.out.println(name);
         */
        // System.out.printil(moshe());

        System.out.println(isFirstNumberLarger(65, 87)); // false
    }

    public static boolean isFirstNumberLarger(int x, int y) {
        if (x > y) {
            return true;
        } else {
            return false;
        }
        // or shorter: return x > y;
    }

    // public static int sum(int x, int y){
    //    return x + y;
    //}
    /*public static String moshe() {
        return "moshe";
    }
    */

    public void moshiko() {
    }

}
