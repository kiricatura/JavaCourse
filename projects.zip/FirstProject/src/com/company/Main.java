package com.company;

public class Main {

    public static void main(String[] args) {
        /* lesson 1
        String name;
        name = "Kiril";
        // Method
    System.out.println("Hello" + name);
    System.out.println("How are you" + name);
    System.out.println("Hello" + name);

        int age = 38;
        System.out.println(name + " is " + age + " years old");
        age = 30 + 8;
        age += 5;  // age = age + 5;
        age -= 5;   // age = age - 5;
        age++;  // age = age + 1;
        age--;  // age = age - 1;
        age = 29;
        System.out.println(age);
        System.out.println(age + 7); // stays number
        System.out.println(age + "7");  // becomes string

        Boolean isMale = true;
        // boolean b = 5==4; its the same as boolean b = false;
        System.out.println(name + " is " + isMale + " male");
        int views = 2147483647;  //maximum for int value possible - otherwise becomes negative

        int temp = 4;
        if (temp < 4){
            System.out.println("The temperature is OK");
        } else if (temp > 4) {
            System.out.println("The temperature is too hot!");
        } else {System.out.println(" The temp is " + temp);}
        */

        /*lesson 2 - loops
        // loop type 1
        for (int i = 0; i < 4; i++) {
            System.out.println("loop " + i);
        }
        // loop type 2
        int i = 0;
        while (i < 100) {
            System.out.println("while: " + i++);
        }
        // loop type 3 - used only when we need firs to do then to check
        int i = 100;
        do{
            System.out.println("doWhile " + i++);
        }while(i !=0);
        */

    }
}
